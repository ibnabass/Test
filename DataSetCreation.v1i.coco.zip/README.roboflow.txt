
DataSetCreation - v1 2021-10-21 11:54pm
==============================

This dataset was exported via roboflow.ai on October 21, 2021 at 9:55 PM GMT

It includes 638 images.
Bouteille are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


